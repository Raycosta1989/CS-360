package com.example.eventtracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class UserDatabaseHelper(context: Context) : SQLiteOpenHelper(context, "EventTrackerDB", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        // Create user table
        db.execSQL("""
            CREATE TABLE users (
                username TEXT PRIMARY KEY,
                password TEXT
            )
        """.trimIndent())

        // Create event table
        db.execSQL("""
            CREATE TABLE events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                date TEXT
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS events")
        onCreate(db)
    }

    // USER METHODS
    fun userExists(username: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM users WHERE username = ?", arrayOf(username))
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    fun validateUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM users WHERE username = ? AND password = ?",
            arrayOf(username, password)
        )
        val valid = cursor.count > 0
        cursor.close()
        return valid
    }

    fun createUser(username: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
        }
        return db.insert("users", null, values) != -1L
    }

    // EVENT METHODS
    fun insertEvent(name: String, date: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("name", name)
            put("date", date)
        }
        return db.insert("events", null, values) != -1L
    }

    fun getAllEvents(): List<Pair<String, String>> {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT name, date FROM events", null)
        val events = mutableListOf<Pair<String, String>>()
        while (cursor.moveToNext()) {
            val name = cursor.getString(0)
            val date = cursor.getString(1)
            events.add(Pair(name, date))
        }
        cursor.close()
        return events
    }

    fun deleteEvent(name: String): Boolean {
        val db = writableDatabase
        return db.delete("events", "name = ?", arrayOf(name)) > 0
    }

    fun updateEvent(oldName: String, newName: String, newDate: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("name", newName)
            put("date", newDate)
        }
        return db.update("events", values, "name = ?", arrayOf(oldName)) > 0
    }
}