package com.example.eventtracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DashboardActivity : AppCompatActivity() {

    private lateinit var dbHelper: UserDatabaseHelper
    private lateinit var eventAdapter: EventAdapter
    private lateinit var eventRecyclerView: RecyclerView
    private lateinit var welcomeText: TextView
    private lateinit var addEventButton: Button
    private lateinit var logoutButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dashboard_activity)

        // Initialize views
        welcomeText = findViewById(R.id.welcomeText)
        addEventButton = findViewById(R.id.addEventButton)
        logoutButton = findViewById(R.id.logoutButton)
        eventRecyclerView = findViewById(R.id.eventRecyclerView)

        // Get username from intent
        val username = intent.getStringExtra("username") ?: "User"
        welcomeText.text = "Welcome, $username!"

        // Set up database and RecyclerView
        dbHelper = UserDatabaseHelper(this)
        eventRecyclerView.layoutManager = LinearLayoutManager(this)
        loadEvents()

        // Add Event button
        addEventButton.setOnClickListener {
            val intent = Intent(this, AddEventActivity::class.java)
            startActivity(intent)
        }

        // Logout button
        logoutButton.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        loadEvents() // Refresh list when returning from AddEventActivity
    }

    private fun loadEvents() {
        val events = dbHelper.getAllEvents()
        eventAdapter = EventAdapter(events)
        eventRecyclerView.adapter = eventAdapter
    }
}

